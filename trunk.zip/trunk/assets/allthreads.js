if (typeof jQuery != 'undefined') {
	$(function(){	
		allthreads();
	});
}
else{
	console.log("JQuery failed to load");
}			


// LIST FORUM TOPICS - MAIN PAGE
function allthreads(){
	
	// $('table:eq(4)>tbody>tr>td>table>tbody>tr').length -- length of main board is always 11, can be used as a double check
	$('table:eq(4)').addClass('tblMainBoardOuter');
	$('table:eq(4)>tbody>tr>td>table').addClass('tblMainBoard').find('tr').each(function(index){ 
		
		if(index==0){ // remove subject line
			$(this).css({display: 'none'});
		}
																
		var k = "";
		$(this).find('td').each(function(index){ // loop each td
																					 
			if(index==0){ // if 1st td keep in one line.
			
				if($(this).find('small').length>1){ // if topic has many pages add | character to last one
					$(this).find('small').last().append('<br><div style="width:auto;padding-bottom:5px;"></div>'); 
				}
				k += "<span class='topic'>" + $(this).html()+"</span>";
			}
			else if(index==1){ // started user - blank
				k += "";
			}
			else if(index==2){ // replies
				k += "<span class='other'>Replies [" + $(this).html()+"]&nbsp;&nbsp;-&nbsp;&nbsp;</span>";
			}
			else if(index==3){ // if last td omit the - character
				k += "<span class='other'>Last Reply [" + $(this).html()+"]</span>";
			}
			else{ // write all in one line
				k +=  "<span class='other'>" +$(this).html()+"&nbsp;&nbsp;-&nbsp;&nbsp;</span>";
			}
		})
		$(this).html("<td class='row'>"+k+"</td>");
		
	})
	
	// get title table , by removing 2nd td of 1st table
	$('table:eq(0)>tbody>tr>td:eq(1)').css({display: 'none'});
	$('table:eq(0)').addClass('titleMain');
	
	//remove a tags (eg: ads,board desc)
	$('#MainWrapper').children("b:eq(0),a:eq(0),a:eq(1),a:eq(2)").css({display: 'none'});

	// remove top start new & favorite
	$('table:eq(3)>tbody>tr').children("td:eq(0),td:eq(1)").css({display: 'none'});
	$('table:eq(3)').addClass('navPagingTop');
	
	// remove bottom start new & favorite
	$('table:eq(6)>tbody>tr').children("td:eq(0),td:eq(1)").remove();
	$('table:eq(6)').addClass('navPagingBot');
	
	//remove text that not are inside tags
	$('#MainWrapper')
	  .contents()
	  .filter(function() {
		return this.nodeType == 3; //Node.TEXT_NODE
	  }).remove();
	  
	  //remove pages text
	  $('.navPagingTop tbody>tr>td')
	  .contents()
	  .filter(function() {
		return this.nodeType == 3; //Node.TEXT_NODE
	  }).remove();
	  
	 $('.navPagingBot tbody>tr>td')
	  .contents()
	  .filter(function() {
		return this.nodeType == 3; //Node.TEXT_NODE
	  }).remove();
	 

}