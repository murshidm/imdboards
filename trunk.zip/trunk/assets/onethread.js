if (typeof jQuery != 'undefined') {
	$(function(){	
		onethread();
	});
}
else{
		console.log("JQuery failed to load");
}


	
// LIST TOPIC - INDIVIDUAL THREAD
function onethread(){
	
	// get title table , by removing 2nd td of 1st table
	$('table:eq(0)>tbody>tr>td:eq(1)').css({display: 'none'});
	$('table:eq(0)').addClass('titleMain');
	
	// internal board table
	$('table:eq(3)>tbody>tr').children("td:eq(1),td:eq(2),td:eq(3),td:eq(4)").css({display: 'none'});
	$('table:eq(3)').addClass('tblInternalMainBoardOuter');
	$('.tblInternalMainBoardOuter>tbody>tr>td:eq(0)>table:eq(1)').addClass('tblInternalMainBoard');
	

	
	//remove unnecessary tables. which are not -> table(3) tr childrens td(1)
	
	
	$('.tblInternalMainBoard').find('tbody:first >tr').each(function(index){ 
    	if(index==0){ // remove subject line
			$(this).css({display: 'none'});
		}
		
		var k = "";
		var mytds = $(this).children('td'); // root td's under tr
		
		
		if(mytds.length==1){ // current topic
			$(mytds).find('table:eq(1)>tbody>tr>td>table>tbody>tr>td:eq(1)').css({'display':'none'});		
			k += "<a name='"+$(mytds).find('table:eq(0) a').attr('name')+"'></a>";
			k += "<span class='subject'>" + $(mytds).find('table:eq(0)').text() + "</span>"; // get subject
			k += "<table class='tblCurrentTopic'>"+$(mytds).find('table:eq(1)').html()+"</table>";
			//$('.tblInternalMainBoardOuter>tbody>tr>td').addClass('internalNavPaging');
			$('.tblInternalMainBoardOuter>tbody>tr>td').find('>a').addClass('internalNavPagingLinks');
			
			$(this).html("<td class='row2'>"+k+"</td>");
    	}
    	else if(mytds.length==3){ // other replies in thread. if 3 columns take them from td's to spans
			$(mytds).each(function(index){
				if(index==0) // 1st td col
				 	k += "<span class='replyTopic'>" + $(this).html()+"</span>";
				else if(index==1) // 2nd td
				 	k += "<span class='replyUser'>" + $(this).html()+"</span>";
				else if(index==2) // 3rd td
				 	k += "<span class='replyDate'>" + $(this).html()+"</span>";
				
			})
			 $(this).html("<td class='row'>"+k+"</td>");
    	}
		
	}
	);
	
	//remove href for user details
	$('.replyUser').find('a').removeAttr('href')
	$('.tblCurrentTopic').find('a').removeAttr('href')
	
	//backlink
	$('#MainWrapper').children('a').addClass('backlink')

}

