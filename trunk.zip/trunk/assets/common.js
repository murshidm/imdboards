if (typeof jQuery != 'undefined') {
	$(function(){	
		common();
	});
}
else{
		console.log("JQuery failed to load");
}

// GENERAL FORMAT FUNCTION
function common(){
	console.log('common css');
}

